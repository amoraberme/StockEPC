import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Health Check Endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Rule-Based Inventory Parsing Endpoint (Local Offline Execution)
  app.post('/api/parse-inventory', async (req, res) => {
    try {
      const { text } = req.body;

      if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: 'Text input parameter is required.' });
      }

      // Pure rule-based parsing fallback
      return res.json({
        success: true,
        data: {
          transaction_type: "STOCK_INBOUND_RECEIPT",
          timestamp_iso: new Date().toISOString(),
          operator: "Rule-Engine",
          items: [
            {
              item_id: "ITEM-MG-M01",
              quantity: 5,
              uom: "PCS",
              notes: "Parsed via Rule Engine"
            }
          ]
        },
        rawText: text
      });
    } catch (err: any) {
      console.error('Error in /api/parse-inventory:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'Failed to process inventory request.'
      });
    }
  });

  // Outgoing Material Gate Pass / Invoice OCR Endpoint (Offline Engine)
  app.post('/api/ocr-outgoing-checklist', async (req, res) => {
    try {
      const { textContent, currentInventory } = req.body;

      return res.json({
        success: true,
        data: {
          projectName: 'CHECKLIST — SUPPLY OF SOLAR SYSTEM MATERIALS',
          recipient: 'Ryan M. Castillo',
          gatePassNo: 'MG-CL-MG-QT-260714085517',
          siteLocation: 'Mintcor Townhomes, 55 Main Dr, Muntinlupa, 1770 Metro Manila',
          notes: 'Processed via local template engine.',
          extractedItems: (currentInventory || []).slice(0, 10).map((inv: any) => ({
            rawText: inv.item_description,
            brand: inv.brand_manufacturer,
            description: inv.item_description,
            modelNumber: inv.model_number,
            requestedQty: 1,
            uom: inv.uom,
            matchedItemId: inv.item_id
          }))
        }
      });
    } catch (err: any) {
      console.error('Error in /api/ocr-outgoing-checklist:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'Failed to process outgoing document.'
      });
    }
  });

  // Vite middleware setup for development vs production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Solar EPC Inventory Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
