import React, { useState } from 'react';
import { 
  Menu, 
  X, 
  Zap, 
  BarChart3, 
  ClipboardCheck, 
  History, 
  Database, 
  AlertTriangle, 
  RefreshCw, 
  User, 
  ChevronRight,
  ShieldAlert,
  Boxes
} from 'lucide-react';
import { Button } from './ui/button';
import { UserProfile } from '../types';
import { MgSolarLogo } from './MgSolarLogo';

export type NavTab = 'inventory' | 'parser' | 'history';

interface SidebarLayoutProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  lowStockCount: number;
  totalItemsCount: number;
  onResetDefaultData: () => void;
  currentUser: UserProfile;
  onOpenProfile: () => void;
  children: React.ReactNode;
}

const NAV_ITEMS: { id: NavTab; label: string; description: string; icon: React.FC<{ className?: string }> }[] = [
  {
    id: 'inventory',
    label: 'Stock Control',
    description: 'Hardware Catalog & Movement',
    icon: Zap,
  },
  {
    id: 'parser',
    label: 'Outgoing Checklist',
    description: 'Project Material Dispatch & Inventory Reduction',
    icon: ClipboardCheck,
  },
  {
    id: 'history',
    label: 'Audit Logs',
    description: 'Chronological Event History',
    icon: History,
  }
];

export const SidebarLayout: React.FC<SidebarLayoutProps> = ({
  activeTab,
  setActiveTab,
  lowStockCount,
  totalItemsCount,
  onResetDefaultData,
  currentUser,
  onOpenProfile,
  children
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  const activeItemInfo = NAV_ITEMS.find((item) => item.id === activeTab) || NAV_ITEMS[0];

  const handleSelectTab = (tab: NavTab) => {
    setActiveTab(tab);
    setIsMobileMenuOpen(false);
  };

  return (
    <div id="sidebar-layout-root" className="min-h-screen bg-zinc-50 text-zinc-950 flex flex-col md:flex-row font-sans overflow-x-hidden w-full">
      {/* Desktop Sidebar (md+) */}
      <aside 
        id="desktop-sidebar" 
        className="hidden md:flex flex-col w-64 lg:w-72 bg-white border-r border-zinc-200 fixed top-0 bottom-0 left-0 z-40 justify-between shadow-xs"
      >
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Sidebar Header: Logo & Title */}
          <div className="p-5 border-b border-zinc-100 flex items-center space-x-3 bg-zinc-50/50">
            <div className="p-2 bg-white border border-zinc-200 rounded-xl shadow-2xs shrink-0">
              <MgSolarLogo size="sm" showText={false} />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm font-black tracking-tight text-zinc-950 uppercase truncate">
                MG SOLAR <span className="text-zinc-500 font-mono text-[10px]">EPC</span>
              </h1>
              <p className="text-[11px] text-zinc-500 truncate font-medium">
                Hardware Inventory
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="p-3 space-y-1 flex-1">
            <div className="px-3 py-2 text-[10px] font-extrabold uppercase tracking-wider text-zinc-400">
              Workspace Modules
            </div>

            <nav className="space-y-1">
              {NAV_ITEMS.map((item) => {
                const IconComponent = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer group ${
                      isActive
                        ? 'bg-black text-white shadow-sm'
                        : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <IconComponent className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-zinc-500 group-hover:text-zinc-950'}`} />
                      <div className="text-left truncate">
                        <div className="leading-tight">{item.label}</div>
                        <div className={`text-[10px] font-normal truncate ${isActive ? 'text-zinc-300' : 'text-zinc-400'}`}>
                          {item.description}
                        </div>
                      </div>
                    </div>

                    {item.id === 'inventory' && (
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono shrink-0 ml-1 ${
                        isActive ? 'bg-zinc-800 text-white' : 'bg-zinc-100 text-zinc-700 border border-zinc-200'
                      }`}>
                        {totalItemsCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Low Stock Alert Widget Card */}
            {lowStockCount > 0 && (
              <div className="mt-6 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-950 space-y-2">
                <div className="flex items-center space-x-2 text-rose-800 font-bold text-xs">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 animate-pulse" />
                  <span>Critical Stock Alert</span>
                </div>
                <p className="text-[11px] text-rose-700 leading-snug">
                  <strong>{lowStockCount}</strong> hardware items below reorder threshold.
                </p>
                <button
                  onClick={() => handleSelectTab('inventory')}
                  className="w-full text-center text-[11px] font-extrabold bg-rose-600 text-white py-1.5 px-2 rounded-lg hover:bg-rose-700 transition-colors shadow-2xs"
                >
                  Review Low Stock →
                </button>
              </div>
            )}
          </div>

          {/* Sidebar Footer: User Session & Actions */}
          <div className="p-3 border-t border-zinc-200 bg-zinc-50/80 space-y-2">
            {/* Active User Card */}
            <div 
              onClick={onOpenProfile}
              className="flex items-center justify-between p-2 rounded-xl border border-zinc-200 bg-white hover:border-zinc-300 transition-all cursor-pointer shadow-2xs"
            >
              <div className="flex items-center space-x-2 min-w-0">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black text-white shrink-0 ${currentUser.avatarColor || 'bg-zinc-900'}`}>
                  {currentUser.fullName.substring(0, 1)}
                </div>
                <div className="min-w-0 text-left">
                  <div className="text-xs font-bold text-zinc-950 truncate">{currentUser.fullName}</div>
                  <div className="text-[10px] text-zinc-500 font-mono truncate">{currentUser.role}</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-zinc-400 shrink-0" />
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Top Navigation Header (< md) */}
      <header id="mobile-top-header" className="md:hidden sticky top-0 z-30 bg-white border-b border-zinc-200 px-4 h-14 flex items-center justify-between shadow-2xs">
        <div className="flex items-center space-x-2">
          <MgSolarLogo size="sm" showText={false} />
          <span className="font-extrabold text-sm text-zinc-950 uppercase tracking-tight">
            MG SOLAR
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {lowStockCount > 0 && (
            <button
              onClick={() => handleSelectTab('inventory')}
              className="flex items-center space-x-1 bg-rose-600 text-white px-2.5 py-1 rounded-full text-[10px] font-mono font-extrabold shadow-2xs"
            >
              <span>{lowStockCount} Low</span>
            </button>
          )}

          <button
            onClick={onOpenProfile}
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black text-white ${currentUser.avatarColor || 'bg-zinc-900'}`}
          >
            {currentUser.fullName.substring(0, 1)}
          </button>
        </div>
      </header>

      {/* Main Dedicated Content Workspace (Offset on desktop for sidebar) */}
      <div id="main-content-wrapper" className="flex-1 md:pl-64 lg:pl-72 flex flex-col min-w-0 max-w-full min-h-screen overflow-x-hidden">
        {/* Dedicated Page Workspace Top Header */}
        <header id="dedicated-workspace-topbar" className="bg-white border-b border-zinc-200 px-4 sm:px-6 lg:px-8 py-4 sticky top-0 z-20 shadow-2xs">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-extrabold font-mono uppercase tracking-wider text-zinc-400">
                  Module View
                </span>
                <span className="text-zinc-300">•</span>
                <span className="text-[10px] font-bold text-zinc-600 uppercase">
                  MG Solar EPC
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-black text-zinc-950 tracking-tight uppercase leading-tight">
                {activeItemInfo.label}
              </h1>
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              {lowStockCount > 0 && (
                <button
                  onClick={() => setActiveTab('inventory')}
                  className="hidden sm:flex items-center space-x-1.5 bg-rose-50 text-rose-800 border border-rose-200 px-3 py-1 rounded-xl text-xs font-mono font-bold hover:bg-rose-100 transition-colors"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>{lowStockCount} Low Stock</span>
                </button>
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={onOpenProfile}
                className="flex items-center space-x-1.5 text-xs font-bold border-zinc-300 bg-zinc-50 hover:bg-zinc-100 h-8 px-2.5"
              >
                <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black text-white shrink-0 ${currentUser.avatarColor || 'bg-zinc-900'}`}>
                  {currentUser.fullName.substring(0, 1)}
                </div>
                <span className="hidden sm:inline max-w-[100px] truncate">{currentUser.fullName}</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Dedicated Page Main Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 pb-24 md:pb-8 space-y-6 max-w-7xl w-full mx-auto min-w-0 max-w-full">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Docked Navigation Bar (< md) matching modern mobile app layout */}
      <nav id="mobile-bottom-dock-nav" className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-zinc-200/80 px-3 py-2 flex items-center justify-around shadow-xl rounded-t-2xl">
        <button
          onClick={() => handleSelectTab('inventory')}
          className={`flex items-center transition-all cursor-pointer ${
            activeTab === 'inventory'
              ? 'bg-black text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-sm space-x-1.5'
              : 'flex-col items-center text-zinc-500 hover:text-zinc-900 space-y-0.5 text-[10px] font-medium px-2 py-1'
          }`}
        >
          <Zap className={`w-4 h-4 ${activeTab === 'inventory' ? 'text-white' : 'text-zinc-600'}`} />
          <span>Products</span>
        </button>

        <button
          onClick={() => handleSelectTab('parser')}
          className={`flex items-center transition-all cursor-pointer ${
            activeTab === 'parser'
              ? 'bg-black text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-sm space-x-1.5'
              : 'flex-col items-center text-zinc-500 hover:text-zinc-900 space-y-0.5 text-[10px] font-medium px-2 py-1'
          }`}
        >
          <ClipboardCheck className={`w-4 h-4 ${activeTab === 'parser' ? 'text-white' : 'text-zinc-600'}`} />
          <span>Dispatch</span>
        </button>

        <button
          onClick={() => handleSelectTab('history')}
          className={`flex items-center transition-all cursor-pointer ${
            activeTab === 'history'
              ? 'bg-black text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-sm space-x-1.5'
              : 'flex-col items-center text-zinc-500 hover:text-zinc-900 space-y-0.5 text-[10px] font-medium px-2 py-1'
          }`}
        >
          <History className={`w-4 h-4 ${activeTab === 'history' ? 'text-white' : 'text-zinc-600'}`} />
          <span>Audit</span>
        </button>

        <button
          onClick={onOpenProfile}
          className="flex flex-col items-center text-zinc-500 hover:text-zinc-900 space-y-0.5 text-[10px] font-medium px-2 py-1 cursor-pointer"
        >
          <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black text-white ${currentUser.avatarColor || 'bg-zinc-900'}`}>
            {currentUser.fullName.substring(0, 1)}
          </div>
          <span>Profile</span>
        </button>
      </nav>
    </div>
  );
};
