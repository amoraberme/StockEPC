import React from 'react';

interface MgSolarLogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const MgSolarLogo: React.FC<MgSolarLogoProps> = ({
  className = '',
  showText = true,
  size = 'md'
}) => {
  const sizeMap = {
    sm: 'h-8',
    md: 'h-12',
    lg: 'h-20',
    xl: 'h-32'
  };

  return (
    <div className={`inline-flex items-center justify-center ${className}`}>
      <svg
        viewBox={showText ? "0 0 1200 1220" : "0 0 1100 1020"}
        className={`${sizeMap[size]} w-auto object-contain transition-transform duration-200 hover:scale-[1.02] drop-shadow-xs`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Sun Gradient */}
          <linearGradient id="mgSunGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFDE00" />
            <stop offset="45%" stopColor="#FF8800" />
            <stop offset="100%" stopColor="#E52B00" />
          </linearGradient>

          {/* Sun Ray Bevel */}
          <linearGradient id="mgSunRayDark" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E57C00" />
            <stop offset="100%" stopColor="#C41A00" />
          </linearGradient>

          {/* M Dark Navy Blue */}
          <linearGradient id="mgMDark" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#0B1E4A" />
            <stop offset="100%" stopColor="#07122E" />
          </linearGradient>

          {/* M Light Blue Bevel */}
          <linearGradient id="mgMLight" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1B52B3" />
            <stop offset="50%" stopColor="#2460C7" />
            <stop offset="100%" stopColor="#3B7AE8" />
          </linearGradient>

          {/* Green G House Gradient */}
          <linearGradient id="mgGGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#67C832" />
            <stop offset="40%" stopColor="#3E9B1F" />
            <stop offset="100%" stopColor="#1E610A" />
          </linearGradient>

          {/* Solar Panel Gradient */}
          <linearGradient id="mgPanelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3468B3" />
            <stop offset="100%" stopColor="#13356D" />
          </linearGradient>
        </defs>

        <g transform="translate(40, 20)">
          {/* 1. SUNBURST RAYS (Top-Left) */}
          <g id="sunburst">
            <polygon points="260,110 240,-10 300,100" fill="url(#mgSunGrad)" />
            <polygon points="320,130 360,10 350,135" fill="url(#mgSunGrad)" />
            <polygon points="375,165 470,30 400,185" fill="url(#mgSunGrad)" />
            <polygon points="420,215 540,120 435,250" fill="url(#mgSunGrad)" />
            <polygon points="450,280 580,220 455,315" fill="url(#mgSunGrad)" />
            <polygon points="460,350 590,340 455,380" fill="url(#mgSunGrad)" />

            <polygon points="195,115 130,-50 220,125" fill="url(#mgSunGrad)" />
            <polygon points="140,150 20,-20 175,170" fill="url(#mgSunGrad)" />
            <polygon points="95,205 -50,60 135,225" fill="url(#mgSunGrad)" />
            <polygon points="65,270 -90,170 110,290" fill="url(#mgSunGrad)" />
            <polygon points="50,340 -100,280 95,355" fill="url(#mgSunGrad)" />
            <polygon points="50,410 -80,390 95,420" fill="url(#mgSunGrad)" />
            <polygon points="65,480 -40,490 110,480" fill="url(#mgSunGrad)" />
            <polygon points="95,550 20,590 140,530" fill="url(#mgSunGrad)" />
            <polygon points="145,610 90,680 185,570" fill="url(#mgSunGrad)" />
            <polygon points="205,655 180,740 240,600" fill="url(#mgSunGrad)" />

            <polygon points="260,110 240,-10 270,105" fill="url(#mgSunRayDark)" />
            <polygon points="375,165 470,30 385,175" fill="url(#mgSunRayDark)" />
            <polygon points="140,150 20,-20 155,160" fill="url(#mgSunRayDark)" />
            <polygon points="65,270 -90,170 85,280" fill="url(#mgSunRayDark)" />

            <path d="M 425,230 A 210,210 0 1,0 200,450 A 155,155 0 1,1 425,230 Z" fill="url(#mgSunGrad)" />
          </g>

          {/* 2. BLUE 'M' CHEVRON RISING ARROW */}
          <g id="m-arrow">
            <polygon points="320,310 370,310 370,1000 320,1000" fill="url(#mgMDark)" />
            <polygon points="370,310 420,310 420,1000 370,1000" fill="url(#mgMLight)" />

            <polygon points="320,310 610,580 920,320 1020,300 930,460 610,740 420,530 420,310" fill="url(#mgMDark)" />
            <polygon points="420,310 610,500 1030,280 1020,300 920,320 610,580" fill="url(#mgMLight)" />

            <polygon points="850,280 1035,280 930,460" fill="url(#mgMLight)" />
            <polygon points="850,280 1035,280 950,340" fill="#649EFF" opacity="0.6" />
          </g>

          {/* 3. GREEN 'G' HOUSE WITH SOLAR ROOF */}
          <g id="g-house">
            <polygon points="830,480 580,700 620,730 830,545 1040,730 1080,700" fill="#2D7A17" />

            <polygon points="825,500 620,680 825,680" fill="url(#mgPanelGrad)" stroke="#FFFFFF" strokeWidth="5" strokeLinejoin="round" />
            <line x1="720" y1="590" x2="825" y2="590" stroke="#FFFFFF" strokeWidth="3.5" />
            <line x1="670" y1="635" x2="825" y2="635" stroke="#FFFFFF" strokeWidth="3.5" />
            <line x1="722" y1="500" x2="722" y2="680" stroke="#FFFFFF" strokeWidth="3.5" />

            <polygon points="835,500 1040,680 835,680" fill="url(#mgPanelGrad)" stroke="#FFFFFF" strokeWidth="5" strokeLinejoin="round" />
            <line x1="835" y1="590" x2="940" y2="590" stroke="#FFFFFF" strokeWidth="3.5" />
            <line x1="835" y1="635" x2="990" y2="635" stroke="#FFFFFF" strokeWidth="3.5" />
            <line x1="938" y1="500" x2="938" y2="680" stroke="#FFFFFF" strokeWidth="3.5" />

            <path d="M 630,730 L 830,555 L 1030,730 L 1030,1000 L 630,1000 Z" fill="url(#mgGGrad)" />

            <path d="M 705,780 L 955,780 L 955,870 L 840,870 L 840,930 L 1030,930 L 1030,1000 Z" fill="#FFFFFF" />

            <path d="M 840,780 L 1020,780 L 1020,870 L 840,870 Z" fill="url(#mgGGrad)" />
          </g>

          {/* 4. TYPOGRAPHY 'mg SOLAR' */}
          {showText && (
            <g id="typography" transform="translate(190, 1060)">
              {/* 'm' */}
              <path d="M 0,110 L 0,0 C 20,-3 45,0 65,12 C 85,25 90,45 95,60 C 105,25 125,0 160,0 C 190,0 215,20 220,50 L 220,110 L 175,110 L 175,55 C 175,40 165,33 150,33 C 135,33 125,40 125,55 L 125,110 L 80,110 L 80,55 C 80,40 70,33 55,33 C 40,33 30,40 30,55 L 30,110 Z" fill="#000000" />

              {/* 'g' */}
              <path d="M 235,0 L 320,0 C 345,0 365,15 365,40 L 365,110 C 365,125 350,140 325,140 L 235,140 L 235,105 L 320,105 L 320,75 L 280,75 C 255,75 235,60 235,35 Z M 280,35 L 320,35 L 320,45 L 280,45 Z" fill="#000000" />

              {/* Space */}
              <g transform="translate(410, 0)">
                {/* 'S' */}
                <path d="M 0,100 C 0,125 20,140 50,140 L 95,140 C 120,140 140,125 140,100 L 140,80 C 140,65 125,55 100,50 L 45,40 C 35,38 30,32 30,25 C 30,18 38,15 50,15 L 135,15 L 135,0 L 50,0 C 25,0 0,15 0,38 L 0,55 C 0,70 15,80 40,85 L 95,95 C 105,97 110,103 110,110 C 110,118 100,125 85,125 L 0,125 Z" fill="#000000" />

                {/* 'O' */}
                <path d="M 160,35 C 160,10 180,0 210,0 L 255,0 C 285,0 305,10 305,35 L 305,105 C 305,130 285,140 255,140 L 210,140 C 180,140 160,130 160,105 Z M 195,38 L 195,102 C 195,115 205,123 220,123 L 245,123 C 260,123 270,115 270,102 L 270,38 C 270,25 260,17 245,17 L 220,17 C 205,17 195,25 195,38 Z" fill="#000000" />

                {/* 'L' */}
                <path d="M 325,0 L 360,0 L 360,123 L 450,123 L 450,140 L 325,140 Z" fill="#000000" />

                {/* 'A' */}
                <path d="M 470,140 L 470,35 C 470,10 490,0 520,0 L 555,0 C 585,0 605,10 605,35 L 605,140 L 570,140 L 570,95 L 505,95 L 505,140 Z M 505,78 L 570,78 L 570,35 C 570,23 560,17 545,17 C 530,17 520,23 520,35 L 520,78 Z" fill="#000000" />

                {/* 'R' */}
                <path d="M 625,0 L 710,0 C 735,0 755,10 755,35 L 755,65 C 755,80 740,90 720,95 L 760,140 L 720,140 L 685,95 L 660,95 L 660,140 L 625,140 Z M 660,18 L 660,78 L 705,78 C 718,78 725,70 725,58 L 725,38 C 725,26 718,18 705,18 Z" fill="#000000" />
              </g>
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};


