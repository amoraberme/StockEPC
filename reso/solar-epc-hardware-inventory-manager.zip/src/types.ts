export type TransactionType = 
  | 'INBOUND' 
  | 'OUTBOUND' 
  | 'AUDIT' 
  | 'RESERVATION'
  | 'RESTOCK'
  | 'REMOVED'
  | 'SKU_ADDED'
  | 'SKU_DELETED';

export type CategoryType = 
  | 'PV_MODULE'
  | 'INVERTER'
  | 'BESS'
  | 'PROTECTION_BREAKERS'
  | 'RACKING'
  | 'DC_CABLING'
  | 'MC4_CONNECTOR'
  | 'CONDUIT_FITTINGS'
  | 'GROUNDING'
  | 'FASTENERS'
  | 'CONSUMABLES'
  | 'BOS_SWITCHGEAR';

export type UOMType = 'PCS' | 'METERS' | 'SPOOLS' | 'SETS' | 'BOXES';

export interface TechnicalSpecs {
  power_rating_w?: number;
  capacity_kw_kwh?: string;
  voltage_rating_v?: number;
  cable_cross_section_mm2?: number;
  amperage_rating_a?: number;
  phase?: string;
  ip_rating?: string;
  poles?: string;
  [key: string]: any;
}

export interface StockLevels {
  current_stock: number;
  allocated_stock: number;
  reorder_threshold: number;
  low_stock_alert: boolean;
}

export interface InventoryItem {
  item_id: string;
  brand_manufacturer: string;
  category: CategoryType;
  item_description: string;
  model_number: string;
  quantity: number;
  uom: UOMType;
  technical_specs: TechnicalSpecs;
  stock_levels: StockLevels;
  serial_numbers: string[];
  image_url?: string;
}

export interface UserProfile {
  id: string;
  username: string;
  fullName: string;
  role: string;
  company?: string;
  contactNumber?: string;
  email: string;
  password?: string;
  avatarColor?: string;
}

export const DEFAULT_PROFILES: UserProfile[] = [
  {
    id: 'ryan',
    username: 'ryan',
    fullName: 'Ryan M. Castillo',
    role: 'Liaison Officer',
    company: 'M&G Non-Specialized Wholesale Trading',
    contactNumber: '09352956244',
    email: 'ry.manalo1111@gmail.com',
    password: 'ryan2026',
    avatarColor: 'bg-blue-900'
  },
  {
    id: 'renzel',
    username: 'renzel',
    fullName: 'Renzel G. Rongavilla',
    role: 'Liaison Officer',
    company: 'M&G Non-Specialized Wholesale Trading',
    contactNumber: '09299606023',
    email: 'rongavillarenzel.gs@gmail.com',
    password: 'renzel2026',
    avatarColor: 'bg-emerald-900'
  },
  {
    id: 'noel',
    username: 'noel',
    fullName: 'Noel Jayson E. Santos',
    role: 'Chief Operating Officer',
    company: 'M&G Non-Specialized Wholesale Trading',
    contactNumber: '09198718747',
    email: 'Santosnoel9999@gmail.com',
    password: 'noel2026',
    avatarColor: 'bg-amber-900'
  }
];

export interface InventoryEvent {
  transaction_type: TransactionType;
  project_id?: string;
  notes?: string;
  performed_by?: string;
  timestamp: string;
}

export interface AuditItemMovement extends InventoryItem {
  change_quantity?: number;
  previous_stock?: number;
  new_stock?: number;
}

export interface PRDJsonOutput {
  inventory_event: InventoryEvent;
  items: AuditItemMovement[];
}

export interface ValidationIssue {
  severity: 'error' | 'warning' | 'info';
  rule: string;
  message: string;
  itemId?: string;
}

export interface ValidationResult {
  isValid: boolean;
  issues: ValidationIssue[];
}

export interface SamplePreset {
  id: string;
  title: string;
  description: string;
  promptText: string;
}
