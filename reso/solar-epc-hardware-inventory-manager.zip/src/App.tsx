import React, { useState, useEffect } from 'react';
import { SidebarLayout } from './components/SidebarLayout';
import { InventoryDashboard } from './components/InventoryDashboard';
import { OutgoingChecklistSection } from './components/OutgoingChecklistSection';
import { JsonExportView } from './components/JsonExportModal';
import { TransactionHistoryModal } from './components/TransactionHistoryModal';
import { ItemModal } from './components/ItemModal';
import { SerialNumbersModal } from './components/SerialNumbersModal';
import { PrdSpecModal } from './components/PrdSpecModal';
import { LoginGate } from './components/LoginGate';
import { ProfileModal } from './components/ProfileModal';
import { Toaster } from './components/ui/toaster';
import { toast } from './components/ui/use-toast';

import { InventoryItem, PRDJsonOutput, UserProfile, DEFAULT_PROFILES } from './types';
import { INITIAL_INVENTORY } from './lib/prdSpec';

export default function App() {
  const [activeTab, setActiveTab] = useState<'inventory' | 'parser' | 'history' | 'json'>('inventory');

  // Active Authenticated User Session
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('solar_epc_user_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse user session:', e);
      }
    }
    return DEFAULT_PROFILES[0]; // default session
  });

  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // Active Live Inventory
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const saved = localStorage.getItem('solar_epc_inventory');
    if (saved) {
      try {
        const parsed: InventoryItem[] = JSON.parse(saved);
        // Ensure all items from INITIAL_INVENTORY (including all 25 MG Solar SKUs) are present
        const missing = INITIAL_INVENTORY.filter(
          (init) => !parsed.some((p) => p.item_id === init.item_id)
        );
        if (missing.length > 0) {
          return [...parsed, ...missing];
        }
        return parsed;
      } catch (e) {
        console.error('Failed to parse saved inventory:', e);
      }
    }
    return INITIAL_INVENTORY;
  });

  // Audit Transaction History Logs
  const [auditLogs, setAuditLogs] = useState<PRDJsonOutput[]>(() => {
    const saved = localStorage.getItem('solar_epc_audit_logs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved audit logs:', e);
      }
    }
    return [];
  });

  // Modals state
  const [isItemModalOpen, setIsItemModalOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [serialsItem, setSerialsItem] = useState<InventoryItem | null>(null);
  const [isPrdModalOpen, setIsPrdModalOpen] = useState<boolean>(false);

  // Persist to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('solar_epc_user_session', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('solar_epc_user_session');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('solar_epc_inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('solar_epc_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  // Compute low stock count
  const lowStockCount = inventory.filter((item) => {
    const avail = item.stock_levels.current_stock - item.stock_levels.allocated_stock;
    return avail <= item.stock_levels.reorder_threshold || item.stock_levels.low_stock_alert;
  }).length;

  const operatorTag = currentUser
    ? `${currentUser.fullName} (${currentUser.role})`
    : 'System Operator';

  // Handlers
  const handleResetData = () => {
    if (window.confirm('Reset inventory and clear local modifications back to initial sample catalog?')) {
      setInventory(INITIAL_INVENTORY);
      setAuditLogs([]);
    }
  };

  const handleSaveItem = (savedItem: InventoryItem) => {
    const existingIdx = inventory.findIndex((i) => i.item_id === savedItem.item_id);
    const isNew = existingIdx === -1;
    const oldItem = !isNew ? inventory[existingIdx] : undefined;

    setInventory((prev) => {
      const idx = prev.findIndex((i) => i.item_id === savedItem.item_id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = savedItem;
        return updated;
      }
      return [savedItem, ...prev];
    });

    const txType = isNew ? 'SKU_ADDED' : 'AUDIT';
    const note = isNew
      ? `Added new item: ${savedItem.brand_manufacturer} ${savedItem.model_number} (${savedItem.item_id}) with initial stock of ${savedItem.stock_levels.current_stock} ${savedItem.uom}.`
      : `Updated item details/specifications for ${savedItem.brand_manufacturer} ${savedItem.model_number} (${savedItem.item_id}).`;

    const logEntry: PRDJsonOutput = {
      inventory_event: {
        transaction_type: txType,
        notes: note,
        performed_by: operatorTag,
        timestamp: new Date().toISOString()
      },
      items: [
        {
          ...savedItem,
          change_quantity: isNew ? savedItem.stock_levels.current_stock : (oldItem ? savedItem.stock_levels.current_stock - oldItem.stock_levels.current_stock : 0),
          previous_stock: oldItem ? oldItem.stock_levels.current_stock : 0,
          new_stock: savedItem.stock_levels.current_stock
        }
      ]
    };

    setAuditLogs((prev) => [logEntry, ...prev]);
  };

  const handleDeleteItem = (itemId: string) => {
    const itemToDelete = inventory.find((i) => i.item_id === itemId);
    if (!itemToDelete) return;

    setInventory((prev) => prev.filter((i) => i.item_id !== itemId));

    const logEntry: PRDJsonOutput = {
      inventory_event: {
        transaction_type: 'SKU_DELETED',
        notes: `Deleted hardware item ${itemToDelete.item_id} (${itemToDelete.brand_manufacturer} ${itemToDelete.model_number}) from inventory catalog.`,
        performed_by: operatorTag,
        timestamp: new Date().toISOString()
      },
      items: [
        {
          ...itemToDelete,
          change_quantity: -itemToDelete.stock_levels.current_stock,
          previous_stock: itemToDelete.stock_levels.current_stock,
          new_stock: 0
        }
      ]
    };

    setAuditLogs((prev) => [logEntry, ...prev]);

    toast({
      type: 'low_stock',
      title: 'ITEM DELETED FROM INVENTORY',
      description: `Successfully removed ${itemToDelete.brand_manufacturer} ${itemToDelete.model_number} from catalog.`
    });
  };

  const handleUpdateStock = (itemId: string, currentStockChange: number, allocatedStockChange: number, customNote?: string) => {
    const itemToUpdate = inventory.find((i) => i.item_id === itemId);
    if (!itemToUpdate) return;

    if (currentStockChange < 0 && itemToUpdate.stock_levels.current_stock <= 0) {
      toast({
        type: 'warning',
        title: 'STOCK ALREADY AT ZERO',
        description: `Cannot decrement stock for ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number}. Minimum stock limit is 0.`
      });
      return;
    }

    const oldStock = itemToUpdate.stock_levels.current_stock;
    const newCurrent = Math.max(0, itemToUpdate.stock_levels.current_stock + currentStockChange);
    // Ensure allocated stock never exceeds new physical stock and never drops below 0
    const newAllocated = Math.min(newCurrent, Math.max(0, itemToUpdate.stock_levels.allocated_stock + allocatedStockChange));
    const available = Math.max(0, newCurrent - newAllocated);
    const isLowAlert = available <= itemToUpdate.stock_levels.reorder_threshold;

    setInventory((prev) =>
      prev.map((item) => {
        if (item.item_id === itemId) {
          return {
            ...item,
            stock_levels: {
              ...item.stock_levels,
              current_stock: newCurrent,
              allocated_stock: newAllocated,
              low_stock_alert: isLowAlert
            }
          };
        }
        return item;
      })
    );

    let txType: 'RESTOCK' | 'REMOVED' | 'RESERVATION' | 'AUDIT' = 'AUDIT';
    let autoNote = '';

    if (currentStockChange > 0) {
      txType = 'RESTOCK';
      autoNote = `Restocked +${currentStockChange} ${itemToUpdate.uom} of ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} (Stock: ${oldStock} ➔ ${newCurrent})`;
    } else if (currentStockChange < 0) {
      txType = 'REMOVED';
      autoNote = `Removed ${Math.abs(currentStockChange)} ${itemToUpdate.uom} of ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} (Stock: ${oldStock} ➔ ${newCurrent})`;
    } else if (allocatedStockChange !== 0) {
      txType = 'RESERVATION';
      autoNote = `${allocatedStockChange > 0 ? 'Allocated' : 'Unallocated'} ${Math.abs(allocatedStockChange)} ${itemToUpdate.uom} for project reservation.`;
    } else {
      autoNote = `Stock level adjusted for ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number}.`;
    }

    const FIVE_MINUTES_MS = 5 * 60 * 1000;
    const nowIso = new Date().toISOString();
    const nowMs = Date.now();

    const newLogEntry: PRDJsonOutput = {
      inventory_event: {
        transaction_type: txType,
        notes: customNote ? `${autoNote} [${customNote}]` : autoNote,
        performed_by: operatorTag,
        timestamp: nowIso
      },
      items: [
        {
          ...itemToUpdate,
          stock_levels: {
            ...itemToUpdate.stock_levels,
            current_stock: newCurrent,
            allocated_stock: newAllocated,
            low_stock_alert: isLowAlert
          },
          quantity: newCurrent,
          change_quantity: currentStockChange || allocatedStockChange,
          previous_stock: oldStock,
          new_stock: newCurrent
        }
      ]
    };

    setAuditLogs((prevLogs) => {
      // Look for a recent matching log entry created within the last 5 minutes for the same item & transaction type
      const existingIndex = prevLogs.findIndex((log) => {
        if (!log.inventory_event || !log.items || log.items.length !== 1) return false;
        const logItem = log.items[0];
        if (logItem.item_id !== itemId) return false;
        if (log.inventory_event.transaction_type !== txType) return false;
        if (log.inventory_event.performed_by !== operatorTag) return false;

        const logTime = new Date(log.inventory_event.timestamp).getTime();
        return !isNaN(logTime) && (nowMs - logTime) <= FIVE_MINUTES_MS;
      });

      if (existingIndex !== -1) {
        // Coalesce into existing log
        const updatedLogs = [...prevLogs];
        const existingLog = updatedLogs[existingIndex];
        const existingItem = existingLog.items[0];

        const origPreviousStock = existingItem.previous_stock ?? oldStock;
        const aggregatedChange = (existingItem.change_quantity ?? 0) + (currentStockChange || allocatedStockChange);
        const aggregatedNewCurrent = newCurrent;

        let aggregatedAutoNote = '';
        if (txType === 'RESTOCK') {
          aggregatedAutoNote = `Restocked +${aggregatedChange} ${itemToUpdate.uom} of ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} (Stock: ${origPreviousStock} ➔ ${aggregatedNewCurrent})`;
        } else if (txType === 'REMOVED') {
          aggregatedAutoNote = `Removed ${Math.abs(aggregatedChange)} ${itemToUpdate.uom} of ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} (Stock: ${origPreviousStock} ➔ ${aggregatedNewCurrent})`;
        } else if (txType === 'RESERVATION') {
          aggregatedAutoNote = `${aggregatedChange > 0 ? 'Allocated' : 'Unallocated'} ${Math.abs(aggregatedChange)} ${itemToUpdate.uom} for project reservation.`;
        } else {
          aggregatedAutoNote = `Stock level adjusted for ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number}.`;
        }

        const noteText = customNote ? `${aggregatedAutoNote} [${customNote}]` : aggregatedAutoNote;

        const updatedLog: PRDJsonOutput = {
          ...existingLog,
          inventory_event: {
            ...existingLog.inventory_event,
            notes: noteText,
            timestamp: nowIso
          },
          items: [
            {
              ...existingItem,
              stock_levels: {
                ...itemToUpdate.stock_levels,
                current_stock: aggregatedNewCurrent,
                allocated_stock: newAllocated,
                low_stock_alert: isLowAlert
              },
              quantity: aggregatedNewCurrent,
              change_quantity: aggregatedChange,
              previous_stock: origPreviousStock,
              new_stock: aggregatedNewCurrent
            }
          ]
        };

        // Move updated coalesced log to top of list
        updatedLogs.splice(existingIndex, 1);
        return [updatedLog, ...updatedLogs];
      }

      return [newLogEntry, ...prevLogs];
    });

    // Toast Notifications
    if (isLowAlert) {
      toast({
        type: 'low_stock',
        title: `CRITICAL LOW STOCK ALERT`,
        description: `${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} stock dropped to ${available} ${itemToUpdate.uom} (reorder threshold: ${itemToUpdate.stock_levels.reorder_threshold}).`,
        itemDetails: {
          itemId: itemToUpdate.item_id,
          description: itemToUpdate.item_description,
          currentStock: available,
          reorderThreshold: itemToUpdate.stock_levels.reorder_threshold,
          uom: itemToUpdate.uom
        }
      });
    } else if (currentStockChange > 0) {
      toast({
        type: 'success',
        title: `STOCK RESTOCKED (+${currentStockChange} ${itemToUpdate.uom})`,
        description: `${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} updated to ${newCurrent} ${itemToUpdate.uom}.`
      });
    } else if (currentStockChange < 0) {
      toast({
        type: 'info',
        title: `STOCK DISPATCHED (-${Math.abs(currentStockChange)} ${itemToUpdate.uom})`,
        description: `${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} current stock is now ${newCurrent} ${itemToUpdate.uom}.`
      });
    }
  };

  const handleSaveSerials = (itemId: string, serials: string[]) => {
    const itemToUpdate = inventory.find((i) => i.item_id === itemId);
    if (!itemToUpdate) return;

    setInventory((prev) =>
      prev.map((item) => {
        if (item.item_id === itemId) {
          return {
            ...item,
            serial_numbers: serials
          };
        }
        return item;
      })
    );

    const logEntry: PRDJsonOutput = {
      inventory_event: {
        transaction_type: 'AUDIT',
        notes: `Updated serial numbers for ${itemToUpdate.brand_manufacturer} ${itemToUpdate.model_number} (${serials.length} active serials registered).`,
        performed_by: operatorTag,
        timestamp: new Date().toISOString()
      },
      items: [
        {
          ...itemToUpdate,
          serial_numbers: serials
        }
      ]
    };

    setAuditLogs((prev) => [logEntry, ...prev]);
  };

  // Commit AI Transaction Output to Active Inventory
  const handleCommitTransaction = (prdOutput: PRDJsonOutput) => {
    const enrichedOutput: PRDJsonOutput = {
      ...prdOutput,
      inventory_event: {
        ...prdOutput.inventory_event,
        performed_by: prdOutput.inventory_event?.performed_by || operatorTag
      }
    };

    // 1. Add event to Audit Logs
    setAuditLogs((prev) => [enrichedOutput, ...prev]);

    // 2. Apply stock changes or add new items
    const eventType = enrichedOutput.inventory_event?.transaction_type || 'INBOUND';
    const lowStockAlerts: Array<{
      itemId: string;
      description: string;
      brand: string;
      model: string;
      available: number;
      reorderThreshold: number;
      uom: string;
    }> = [];

    setInventory((prev) => {
      const updatedList = [...prev];

      enrichedOutput.items?.forEach((newItem) => {
        const existingIdx = updatedList.findIndex(
          (i) => i.item_id === newItem.item_id || (i.model_number === newItem.model_number && newItem.model_number)
        );

        if (existingIdx >= 0) {
          const existing = updatedList[existingIdx];
          let currentStock = existing.stock_levels.current_stock;
          let allocatedStock = existing.stock_levels.allocated_stock;

          if (eventType === 'INBOUND' || eventType === 'RESTOCK') {
            currentStock += newItem.quantity || 0;
          } else if (eventType === 'OUTBOUND' || eventType === 'REMOVED') {
            currentStock = Math.max(0, currentStock - (newItem.quantity || 0));
          } else if (eventType === 'RESERVATION') {
            allocatedStock += newItem.quantity || 0;
          } else if (eventType === 'AUDIT') {
            currentStock = newItem.stock_levels?.current_stock ?? currentStock;
            allocatedStock = newItem.stock_levels?.allocated_stock ?? allocatedStock;
          }

          const available = currentStock - allocatedStock;
          const isLow = available <= (existing.stock_levels.reorder_threshold || 10);

          if (isLow) {
            lowStockAlerts.push({
              itemId: existing.item_id,
              description: existing.item_description,
              brand: existing.brand_manufacturer,
              model: existing.model_number,
              available,
              reorderThreshold: existing.stock_levels.reorder_threshold,
              uom: existing.uom
            });
          }

          // Merge serials if present
          const mergedSerials = Array.from(
            new Set([...(existing.serial_numbers || []), ...(newItem.serial_numbers || [])])
          );

          updatedList[existingIdx] = {
            ...existing,
            stock_levels: {
              ...existing.stock_levels,
              current_stock: currentStock,
              allocated_stock: allocatedStock,
              low_stock_alert: isLow
            },
            serial_numbers: mergedSerials
          };
        } else {
          // Add as new item
          updatedList.unshift(newItem);
        }
      });

      return updatedList;
    });

    lowStockAlerts.forEach((alert) => {
      toast({
        type: 'low_stock',
        title: `CRITICAL LOW STOCK ALERT`,
        description: `${alert.brand} ${alert.model} stock dropped to ${alert.available} ${alert.uom} (reorder threshold: ${alert.reorderThreshold}).`,
        itemDetails: {
          itemId: alert.itemId,
          description: alert.description,
          currentStock: alert.available,
          reorderThreshold: alert.reorderThreshold,
          uom: alert.uom
        }
      });
    });

    toast({
      type: 'success',
      title: `TRANSACTION COMMITTED`,
      description: `Successfully logged ${eventType} event with ${enrichedOutput.items?.length || 0} line items.`
    });
  };

  // If not logged in, present password login gate
  if (!currentUser) {
    return <LoginGate onLoginSuccess={(user) => setCurrentUser(user)} />;
  }

  return (
    <SidebarLayout
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      lowStockCount={lowStockCount}
      totalItemsCount={inventory.length}
      onResetDefaultData={handleResetData}
      currentUser={currentUser}
      onOpenProfile={() => setIsProfileModalOpen(true)}
    >
      {activeTab === 'inventory' && (
        <InventoryDashboard
          items={inventory}
          onOpenAddItemModal={() => {
            setEditingItem(null);
            setIsItemModalOpen(true);
          }}
          onEditItem={(item) => {
            setEditingItem(item);
            setIsItemModalOpen(true);
          }}
          onDeleteItem={handleDeleteItem}
          onUpdateStock={handleUpdateStock}
          onOpenSerialsModal={(item) => setSerialsItem(item)}
        />
      )}

      {activeTab === 'parser' && (
        <OutgoingChecklistSection
          onCommitTransaction={handleCommitTransaction}
          currentInventory={inventory}
        />
      )}

      {activeTab === 'history' && (
        <TransactionHistoryModal
          logs={auditLogs}
          onClearLogs={() => setAuditLogs([])}
        />
      )}

      {/* Modals */}
      <ItemModal
        isOpen={isItemModalOpen}
        onClose={() => setIsItemModalOpen(false)}
        onSave={handleSaveItem}
        existingItem={editingItem}
      />

      <SerialNumbersModal
        item={serialsItem}
        onClose={() => setSerialsItem(null)}
        onSaveSerials={handleSaveSerials}
      />

      <PrdSpecModal
        isOpen={isPrdModalOpen}
        onClose={() => setIsPrdModalOpen(false)}
      />

      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onSwitchUser={(user) => setCurrentUser(user)}
        onLogout={() => {
          setCurrentUser(null);
          setIsProfileModalOpen(false);
        }}
        auditLogs={auditLogs}
      />

      <Toaster onFocusItem={() => setActiveTab('inventory')} />
    </SidebarLayout>
  );
}
